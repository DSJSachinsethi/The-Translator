# ⚖️ Gujarati Legal Document Translator

A free, browser-based tool for translating Gujarati legal documents to English — built for judicial offices. Powered by Google Gemini AI (completely free).

**Live Tool →** `https://YOUR-GITHUB-USERNAME.github.io/gujarati-legal-translator`

---

## What It Does

- Translates Gujarati legal documents to accurate English
- Preserves all party names, section numbers (IPC/CrPC/CPC), dates, amounts, and court references exactly
- Supports 9 document types: Plaint, Written Statement, FIR, Affidavit, Court Order, Legal Notice, Application/Petition, Witness Examination, General Legal
- Saves last 20 translations in browser history
- Download translation as `.txt` file
- 100% free — uses Google Gemini AI free tier (1000 translations/day)

---

## Setup Guide (One-Time — 5 Minutes)

### Step 1 — Fork or Copy this Repository

Click the green **"Use this template"** button (or Fork) on the top right of this GitHub page.

Give your repository a name like `gujarati-legal-translator`.

Make sure it is set to **Public**.

### Step 2 — Enable GitHub Pages

1. Go to your repository → click **Settings** (top menu)
2. On the left sidebar, click **Pages**
3. Under "Source", select **Deploy from a branch**
4. Set Branch to **main** and folder to **/ (root)**
5. Click **Save**

Wait 1–2 minutes. GitHub will show you a green link:
`https://YOUR-USERNAME.github.io/gujarati-legal-translator`

That link is your permanent tool URL. Bookmark it.

### Step 3 — Get Your Free Google Gemini API Key

1. Open **[aistudio.google.com](https://aistudio.google.com)** — sign in with Gmail
2. Click **"Get API Key"** → **"Create API Key"**
3. Copy the key (starts with `AIza...`)

### Step 4 — Enter API Key in the Tool

1. Open your tool link
2. Click **"Set API Key"** button (top right corner)
3. Paste your key → click Save
4. Green dot will appear: **"API Connected"**

Done. The key saves in the browser — stenographer does not need to enter it again on the same computer.

---

## Daily Use (Stenographer)

1. Open the bookmarked link
2. Select document type (FIR, Plaint, Written Statement, etc.)
3. Paste Gujarati text in the left box
4. Click **"Translate Document"**
5. Wait 15–30 seconds
6. Copy or Download the English translation
7. Use it to draft the judgment (subject to Hon'ble Judge's review)

---

## Cost

| Item | Cost |
|------|------|
| GitHub hosting | ₹0 — free forever |
| Google Gemini API | ₹0 — free tier: 1000 requests/day |
| Domain / subscription | ₹0 |
| **Total** | **₹0** |

---

## Legal Disclaimer

This tool produces AI-assisted translations for drafting purposes only. All translations must be reviewed and verified by the presiding judicial officer before use in any court proceeding. The tool does not store any document content on any server — all processing happens directly between your browser and Google's API.

---

## Document Types Supported

| Gujarati | English |
|----------|---------|
| દાવો / Plaint | Plaint / Suit |
| જવાબ | Written Statement |
| ફરિયાદ | FIR / Police Report |
| સોગંદનામું | Affidavit / Evidence |
| હુકમ / ચૂકાદો | Court Order / Judgment |
| નોટિસ | Legal Notice |
| અરજી | Application / Petition |
| સાક્ષી | Examination of Witness |
| — | General Legal Document |

---

*Built for Judicial Office use. Confidential.*
